<?php

/**
 * Plugin Name:       Endro Contact Plugin API
 * Description:       This is an API plugin.
 * Version:           1.0.0
 */

@ini_set('upload_max_size', '64M');
@ini_set('post_max_size', '64M');
@ini_set('max_execution_time', '500');

if (function_exists('set_time_limit')) {
  set_time_limit(500);
}

add_action('rest_api_init', 'endro_add_callback_url_endpoint');

function endro_add_callback_url_endpoint()
{
  register_rest_route(
    'endro_mono/v1/', // Namespace
    'contact_form', // Endpoint
    array(
      'methods'  => 'POST',
      'callback' => 'endro_receive_callback'
    )
  );
}


function endro_receive_callback($request_data)
{
  $parameters = $request_data->get_params();

  $data   = array();
  $name   = $parameters['name'];
  $email  = $parameters['email'];
  $msg    = $parameters['msg'];

  if (!isset($name) && !isset($email) && !isset($msg)) {
    $data['status'] = 'Failed';
    $data['message'] = 'Parameters Missing!';
    return $data;
  }

  $email  =  strtolower($email);

  global $wpdb;

  $table_name = $wpdb->prefix . 'contact';
  $query = $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name));

  if (!$wpdb->get_var($query) == $table_name) {
    $create = $wpdb->get_row("CREATE TABLE `" . $table_name . "` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `msg` TEXT NOT NULL , PRIMARY KEY (`id`));");
    $data['create_table'] = $table_name;
    $str_create = substr($create, 0, -1);
    if ($str_create) {
      $data['create_msg'] = $str_create;
    }
  }

  $result = $wpdb->get_row("SELECT * FROM " . $table_name . " WHERE (email = '" . $email . "')", OBJECT);
  if ($result) {
    $data['status'] = 'Failed';
    $data['message'] = "Email exist ";
    return $data;
  }

  $data['status'] = 'Ok';

  $data['received_data'] = array(
    'name'  => $name,
    'email' => $email,
    'msg'   => $msg,
  );

  $keys_list = '';
  $values_list = '';
  foreach ($data['received_data'] as $key => $value) {
    $keys_list .= $key . ",";
    $values_list .= "'" . $value . "',";
  }

  $result = $wpdb->query("INSERT INTO " . $table_name . " (" . substr($keys_list, 0, -1) . ") VALUES(" . substr($values_list, 0, -1) . ")");
  $result = $wpdb->get_row("SELECT id FROM " . $table_name . " ORDER BY id DESC LIMIT 1", OBJECT);
  $data['received_data']['id'] = $result->id;
  $data['message'] = 'Save succesfully';

  return $data;
}
